import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Key, 
  Eye, 
  EyeOff, 
  Save, 
  CheckCircle2, 
  AlertCircle,
  ShieldCheck,
  ExternalLink,
  Zap
} from 'lucide-react';
import { voiceService } from '../services/voiceService';
import { cn } from '../lib/utils';

export default function SettingsPage() {
  const [elevenLabsKey, setElevenLabsKey] = useState('');
  const [openAIKey, setOpenAIKey] = useState('');
  const [showELKey, setShowELKey] = useState(false);
  const [showOAKey, setShowOAKey] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error' | 'idle', message: string }>({ type: 'idle', message: '' });
  const [isTesting, setIsTesting] = useState<'elevenlabs' | 'openai' | null>(null);

  useEffect(() => {
    setElevenLabsKey(localStorage.getItem('elevenlabs_api_key') || '');
    setOpenAIKey(localStorage.getItem('openai_api_key') || '');
  }, []);

  const handleSave = (provider: 'elevenlabs' | 'openai', value: string) => {
    localStorage.setItem(`${provider}_api_key`, value);
    setStatus({ type: 'success', message: `${provider === 'elevenlabs' ? 'ElevenLabs' : 'OpenAI'} API Key saved successfully!` });
    setTimeout(() => setStatus({ type: 'idle', message: '' }), 3000);
  };

  const testConnection = async (provider: 'elevenlabs' | 'openai') => {
    setIsTesting(provider);
    const success = await voiceService.testConnection(provider);
    setIsTesting(null);
    
    if (success) {
      setStatus({ type: 'success', message: `Connection to ${provider === 'elevenlabs' ? 'ElevenLabs' : 'OpenAI'} verified!` });
    } else {
      setStatus({ type: 'error', message: `Failed to connect to ${provider}. Please check your API key.` });
    }
    setTimeout(() => setStatus({ type: 'idle', message: '' }), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div>
        <h1 className="text-4xl font-display font-bold tracking-tight">API Settings</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">
          Configure your API keys to unlock Premium ultra-realistic voices.
        </p>
      </div>

      <div className="grid gap-6">
        {/* ElevenLabs Settings */}
        <div className="glass rounded-3xl p-8 space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6 opacity-10">
            <Zap size={120} className="text-primary-500" />
          </div>
          
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600">
              <Zap size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold">ElevenLabs API</h2>
              <p className="text-sm text-slate-500">Unlock the world's most realistic AI voices.</p>
            </div>
          </div>

          <div className="space-y-4 relative z-10">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">API Key</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type={showELKey ? "text" : "password"}
                  value={elevenLabsKey}
                  onChange={(e) => setElevenLabsKey(e.target.value)}
                  placeholder="Enter your ElevenLabs API Key"
                  className="w-full pl-12 pr-12 py-3.5 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-primary-500 rounded-2xl outline-none transition-all font-mono text-sm"
                />
                <button 
                  onClick={() => setShowELKey(!showELKey)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-primary-500 transition-colors"
                >
                  {showELKey ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <button 
                onClick={() => handleSave('elevenlabs', elevenLabsKey)}
                className="btn-primary py-2.5 px-6 flex items-center gap-2 text-sm"
              >
                <Save size={18} /> Save Key
              </button>
              <button 
                onClick={() => testConnection('elevenlabs')}
                disabled={!elevenLabsKey || isTesting === 'elevenlabs'}
                className="px-6 py-2.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 font-bold text-sm hover:border-primary-500 transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {isTesting === 'elevenlabs' ? (
                  <RefreshCw size={18} className="animate-spin" />
                ) : (
                  <Zap size={18} />
                )}
                Test Connection
              </button>
              <a 
                href="https://elevenlabs.io/api" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-6 py-2.5 rounded-xl text-slate-500 hover:text-primary-500 text-sm font-bold flex items-center gap-2 transition-colors"
              >
                Get API Key <ExternalLink size={14} />
              </a>
            </div>
          </div>
        </div>

        {/* OpenAI Settings */}
        <div className="glass rounded-3xl p-8 space-y-6 relative overflow-hidden">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-400">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h2 className="text-xl font-bold">OpenAI API</h2>
              <p className="text-sm text-slate-500">Use OpenAI TTS for fast and reliable voice generation.</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">API Key</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type={showOAKey ? "text" : "password"}
                  value={openAIKey}
                  onChange={(e) => setOpenAIKey(e.target.value)}
                  placeholder="Enter your OpenAI API Key"
                  className="w-full pl-12 pr-12 py-3.5 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-primary-500 rounded-2xl outline-none transition-all font-mono text-sm"
                />
                <button 
                  onClick={() => setShowOAKey(!showOAKey)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-primary-500 transition-colors"
                >
                  {showOAKey ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <button 
                onClick={() => handleSave('openai', openAIKey)}
                className="btn-primary py-2.5 px-6 flex items-center gap-2 text-sm"
              >
                <Save size={18} /> Save Key
              </button>
              <button 
                onClick={() => testConnection('openai')}
                disabled={!openAIKey || isTesting === 'openai'}
                className="px-6 py-2.5 rounded-xl border-2 border-slate-200 dark:border-slate-700 font-bold text-sm hover:border-primary-500 transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {isTesting === 'openai' ? (
                  <RefreshCw size={18} className="animate-spin" />
                ) : (
                  <ShieldCheck size={18} />
                )}
                Test Connection
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Status Toast */}
      <AnimatePresence>
        {status.type !== 'idle' && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={cn(
              "fixed bottom-8 right-8 p-4 rounded-2xl shadow-2xl flex items-center gap-3 z-[100] border",
              status.type === 'success' ? "bg-green-50 border-green-200 text-green-800" : "bg-red-50 border-red-200 text-red-800"
            )}
          >
            {status.type === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
            <span className="font-bold text-sm">{status.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="p-6 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-3xl flex gap-4">
        <ShieldCheck className="text-blue-600 shrink-0" size={24} />
        <div className="space-y-1">
          <h4 className="text-sm font-bold text-blue-900 dark:text-blue-400">Privacy & Security</h4>
          <p className="text-xs text-blue-800 dark:text-blue-500 leading-relaxed">
            Your API keys are stored locally in your browser's <code>localStorage</code>. They are never sent to our servers except to proxy your voice generation requests directly to the providers.
          </p>
        </div>
      </div>
    </div>
  );
}

function RefreshCw(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  )
}
