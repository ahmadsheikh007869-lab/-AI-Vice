import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic2, 
  Play, 
  Square, 
  Download, 
  Settings2, 
  Volume2, 
  Search,
  Check,
  ChevronDown,
  AlertCircle,
  Info,
  Sparkles,
  Zap,
  RefreshCw,
  Trash2
} from 'lucide-react';
import { voiceService, Voice, GenerationSettings } from '../services/voiceService';
import { cn } from '../lib/utils';

export default function VoiceGenerator() {
  const [text, setText] = useState("नमस्ते! मैं आपका एआई वॉयस जेनरेटर हूँ। मैं हिंदी और अंग्रेजी दोनों भाषाओं में बात कर सकता हूँ।");
  const [voices, setVoices] = useState<Voice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<Voice | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [settings, setSettings] = useState<GenerationSettings>({
    rate: 1.0,
    pitch: 1.0,
    volume: 1.0,
    stability: 0.5,
    similarity_boost: 0.75
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [showVoiceList, setShowVoiceList] = useState(false);
  const [filterCategory, setFilterCategory] = useState('All');
  const [style, setStyle] = useState('Normal');
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const loadVoices = async () => {
      const availableVoices = await voiceService.fetchVoices();
      setVoices(availableVoices);
      if (availableVoices.length > 0) {
        // Try to find a good default Hindi voice if text is Hindi
        const defaultVoice = availableVoices.find(v => v.category === 'Hindi') || availableVoices[0];
        setSelectedVoice(defaultVoice);
      }
    };
    loadVoices();
  }, []);

  // Simple Hindi detection
  const isHindi = (str: string) => /[\u0900-\u097F]/.test(str);

  const filteredVoices = voices.filter(v => {
    const matchesSearch = v.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.lang.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'All' || 
                            (filterCategory === 'Male' && v.gender === 'male') ||
                            (filterCategory === 'Female' && v.gender === 'female') ||
                            (filterCategory === 'Hindi' && v.category === 'Hindi') ||
                            (filterCategory === 'Premium' && v.provider === 'elevenlabs');
    return matchesSearch && matchesCategory;
  });

  const handleGenerate = async () => {
    if (!text || !selectedVoice) return;
    
    if (selectedVoice.provider === 'browser') {
      setIsSpeaking(true);
      voiceService.speak(text, selectedVoice.id, settings, () => {
        setIsSpeaking(false);
      });
      return;
    }

    setIsGenerating(true);
    setAudioUrl(null);
    try {
      const blob = await voiceService.generateAudio(text, selectedVoice, settings);
      if (blob) {
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      }
    } catch (err) {
      console.error("Generation failed:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleStop = () => {
    if (selectedVoice?.provider === 'browser') {
      voiceService.stop();
      setIsSpeaking(false);
    }
  };

  const downloadAudio = () => {
    if (!audioUrl) return;
    const a = document.createElement('a');
    a.href = audioUrl;
    a.download = `voice-ai-${Date.now()}.mp3`;
    a.click();
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-display font-bold tracking-tight flex items-center gap-3">
            Realistic Voice AI
            <span className="text-xs bg-primary-100 dark:bg-primary-900/30 text-primary-600 px-2 py-1 rounded-full font-bold">Dual Mode</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-2">
            <Sparkles size={14} className="text-primary-500" />
            Studio-quality Hindi & English voice generation.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Editor */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <div className="px-4 py-2 rounded-lg bg-primary-600 text-white text-sm font-medium">Text to Speech</div>
                {isHindi(text) && (
                  <div className="px-3 py-2 rounded-lg bg-orange-100 dark:bg-orange-900/30 text-orange-600 text-xs font-bold flex items-center gap-1">
                    <Zap size={12} /> Hindi Detected
                  </div>
                )}
              </div>
              <div className="text-xs text-slate-400 font-medium">{text.length} characters</div>
            </div>
            
            <textarea 
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter your text here (Hindi or English)..."
              className="w-full h-64 bg-transparent border-none focus:ring-0 text-lg resize-none placeholder:text-slate-300 dark:placeholder:text-slate-700 leading-relaxed font-sans"
            />

            {audioUrl && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl flex items-center gap-4 border border-slate-100 dark:border-slate-800"
              >
                <div className="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center text-white shrink-0">
                  <Play size={20} fill="currentColor" />
                </div>
                <div className="flex-1">
                  <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <motion.div 
                      animate={{ x: ["-100%", "100%"] }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                      className="h-full w-1/3 bg-primary-500"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={downloadAudio}
                    className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-all"
                    title="Download MP3"
                  >
                    <Download size={18} />
                  </button>
                  <button 
                    onClick={() => setAudioUrl(null)}
                    className="p-2 hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500 rounded-lg transition-all"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <audio ref={audioRef} src={audioUrl} autoPlay className="hidden" />
              </motion.div>
            )}

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <button 
                  onClick={isSpeaking ? handleStop : handleGenerate}
                  disabled={!text || !selectedVoice || isGenerating}
                  className={cn(
                    "btn-primary py-3 px-8 flex items-center gap-3 shadow-xl transition-all active:scale-95 disabled:opacity-50",
                    isSpeaking ? "bg-red-500 hover:bg-red-600 shadow-red-500/20" : "shadow-primary-500/20"
                  )}
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw size={20} className="animate-spin" />
                      Generating...
                    </>
                  ) : isSpeaking ? (
                    <>
                      <Square size={20} fill="currentColor" />
                      Stop Speaking
                    </>
                  ) : (
                    <>
                      <Play size={20} fill="currentColor" />
                      {selectedVoice?.provider === 'browser' ? 'Speak Now' : 'Generate Premium'}
                    </>
                  )}
                </button>

                {(isSpeaking || isGenerating) && (
                  <div className="flex gap-1">
                    {[1, 2, 3, 4].map(i => (
                      <motion.div 
                        key={i}
                        animate={{ height: [8, 24, 8] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: i * 0.1 }}
                        className="w-1 bg-primary-500 rounded-full"
                      />
                    ))}
                  </div>
                )}
              </div>

              {selectedVoice?.provider === 'browser' && (
                <div className="flex items-center gap-3 p-3 bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 rounded-2xl text-amber-800 dark:text-amber-400 text-xs">
                  <AlertCircle size={14} />
                  <span>Download available in Premium Mode.</span>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass rounded-3xl p-6 space-y-4">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Settings2 size={16} className="text-primary-500" />
                Voice Style
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {['Normal', 'News Anchor', 'Storytelling', 'Emotional', 'Energetic'].map(s => (
                  <button
                    key={s}
                    onClick={() => setStyle(s)}
                    className={cn(
                      "px-3 py-2 rounded-xl text-xs font-bold border transition-all",
                      style === s 
                        ? "bg-primary-600 border-primary-600 text-white" 
                        : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 hover:border-primary-500"
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="glass rounded-3xl p-6 space-y-4">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Volume2 size={16} className="text-primary-500" />
                Audio Settings
              </h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    <span>Speed</span>
                    <span>{settings.rate}x</span>
                  </div>
                  <input 
                    type="range" min="0.5" max="2" step="0.1"
                    value={settings.rate}
                    onChange={(e) => setSettings({...settings, rate: parseFloat(e.target.value)})}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full appearance-none cursor-pointer accent-primary-600"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    <span>Pitch</span>
                    <span>{settings.pitch}x</span>
                  </div>
                  <input 
                    type="range" min="0" max="2" step="0.1"
                    value={settings.pitch}
                    onChange={(e) => setSettings({...settings, pitch: parseFloat(e.target.value)})}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full appearance-none cursor-pointer accent-primary-600"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Controls */}
        <div className="space-y-6">
          <div className="glass rounded-3xl p-6 space-y-6">
            <div className="space-y-3">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Voice Selection</label>
              <div className="relative">
                <button 
                  onClick={() => setShowVoiceList(!showVoiceList)}
                  className="w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl hover:border-primary-500 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600">
                      <Mic2 size={20} />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold truncate max-w-[150px]">{selectedVoice?.name || 'Loading voices...'}</p>
                      <p className="text-xs text-slate-500">{selectedVoice?.category || 'Please wait'}</p>
                    </div>
                  </div>
                  <ChevronDown size={20} className={cn("text-slate-400 transition-transform", showVoiceList && "rotate-180")} />
                </button>

                <AnimatePresence>
                  {showVoiceList && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl z-50 max-h-[500px] flex flex-col overflow-hidden"
                    >
                      <div className="p-3 border-b border-slate-100 dark:border-slate-800 space-y-2">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                          <input 
                            type="text"
                            placeholder="Search voices..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border-none rounded-lg text-sm outline-none focus:ring-1 focus:ring-primary-500"
                          />
                        </div>
                        <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-hide">
                          {['All', 'Male', 'Female', 'Hindi', 'Premium'].map(cat => (
                            <button
                              key={cat}
                              onClick={() => setFilterCategory(cat)}
                              className={cn(
                                "px-3 py-1 rounded-full text-[10px] font-bold whitespace-nowrap transition-all",
                                filterCategory === cat 
                                  ? "bg-primary-600 text-white" 
                                  : "bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200"
                              )}
                            >
                              {cat}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="overflow-y-auto p-4 flex-1">
                        <div className="grid grid-cols-1 gap-3">
                          {filteredVoices.length > 0 ? filteredVoices.map((voice) => (
                            <button
                              key={voice.id}
                              onClick={() => {
                                setSelectedVoice(voice);
                                setShowVoiceList(false);
                              }}
                              className={cn(
                                "w-full flex items-center justify-between p-4 rounded-2xl transition-all border-2",
                                selectedVoice?.id === voice.id 
                                  ? "bg-primary-50 dark:bg-primary-900/20 border-primary-500 text-primary-600 shadow-lg shadow-primary-500/10" 
                                  : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-800 hover:border-primary-300"
                              )}
                            >
                              <div className="flex items-center gap-4">
                                <div className={cn(
                                  "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                                  voice.provider === 'elevenlabs' ? "bg-amber-100 text-amber-600" : "bg-slate-100 dark:bg-slate-700 text-slate-500"
                                )}>
                                  {voice.provider === 'elevenlabs' ? <Sparkles size={20} /> : <Mic2 size={20} />}
                                </div>
                                <div className="text-left">
                                  <p className="text-sm font-bold">{voice.name}</p>
                                  <div className="flex gap-2 mt-1">
                                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-500 font-bold uppercase tracking-wider">
                                      {voice.category}
                                    </span>
                                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-500 font-bold uppercase tracking-wider">
                                      {voice.gender}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              {selectedVoice?.id === voice.id && (
                                <div className="w-6 h-6 rounded-full bg-primary-600 flex items-center justify-center text-white">
                                  <Check size={14} />
                                </div>
                              )}
                            </button>
                          )) : (
                            <div className="p-8 text-center text-slate-400 text-sm">No voices found</div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {selectedVoice?.provider === 'elevenlabs' && (
              <div className="space-y-4 p-4 bg-primary-50 dark:bg-primary-900/10 rounded-2xl border border-primary-100 dark:border-primary-900/30">
                <h4 className="text-xs font-bold text-primary-600 uppercase tracking-widest flex items-center gap-2">
                  <Sparkles size={12} /> Premium Controls
                </h4>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-bold text-slate-500">
                      <span>Stability</span>
                      <span>{Math.round((settings.stability || 0.5) * 100)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="1" step="0.01"
                      value={settings.stability}
                      onChange={(e) => setSettings({...settings, stability: parseFloat(e.target.value)})}
                      className="w-full h-1 bg-primary-200 dark:bg-primary-800 rounded-full appearance-none cursor-pointer accent-primary-600"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] font-bold text-slate-500">
                      <span>Similarity Boost</span>
                      <span>{Math.round((settings.similarity_boost || 0.75) * 100)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="1" step="0.01"
                      value={settings.similarity_boost}
                      onChange={(e) => setSettings({...settings, similarity_boost: parseFloat(e.target.value)})}
                      className="w-full h-1 bg-primary-200 dark:bg-primary-800 rounded-full appearance-none cursor-pointer accent-primary-600"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Quick Tips</h4>
              <ul className="text-[11px] text-slate-600 dark:text-slate-400 space-y-2">
                <li className="flex gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary-500 mt-1 shrink-0" />
                  Use Hindi text for Hindi voices to get the best natural accent.
                </li>
                <li className="flex gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary-500 mt-1 shrink-0" />
                  Premium voices offer studio-quality realism and emotion.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
