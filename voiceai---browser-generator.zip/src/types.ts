export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  usage: {
    voiceGenerations: number;
    timeUsed: number;
    credits: number;
  };
  createdAt: string;
}

export interface AudioMetadata {
  id: string;
  userId: string;
  title: string;
  prompt: string;
  text: string;
  voiceId: string;
  voiceName: string;
  audioUrl: string;
  duration: number;
  createdAt: string;
}

export interface VoiceMetadata {
  id: string;
  userId: string;
  name: string;
  description: string;
  previewUrl: string;
  type: 'prebuilt' | 'cloned';
  category: string;
  labels: string[];
  createdAt: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
