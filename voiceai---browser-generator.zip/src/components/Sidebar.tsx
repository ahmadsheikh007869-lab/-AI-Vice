import { Link, useLocation } from 'react-router-dom';
import { 
  Mic2, 
  Settings, 
  ChevronLeft,
  ChevronRight,
  Zap,
  Sparkles
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

const menuItems = [
  { icon: Mic2, label: 'Voice Generator', path: '/' },
  { icon: Settings, label: 'API Settings', path: '/settings' },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <motion.aside 
      initial={false}
      animate={{ width: collapsed ? 80 : 280 }}
      className="h-screen bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col relative z-50 transition-all duration-300 ease-in-out"
    >
      <div className="p-6 flex items-center justify-between">
        {!collapsed && (
          <Link to="/" className="flex items-center gap-2 font-display font-bold text-xl text-primary-600">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center text-white">
              <Mic2 size={20} />
            </div>
            <span>VoiceAI</span>
          </Link>
        )}
        {collapsed && (
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center text-white mx-auto">
            <Mic2 size={20} />
          </div>
        )}
      </div>

      <button 
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 bg-primary-600 text-white rounded-full flex items-center justify-center shadow-lg z-50"
      >
        {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>

      <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto overflow-x-hidden">
        {menuItems.map((item) => {
          const active = location.pathname === item.path || (item.path === '/generate' && location.pathname === '/');
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-4 px-4 py-3 rounded-xl transition-all group",
                active 
                  ? "bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400" 
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
              )}
            >
              <item.icon size={22} className={cn(active ? "text-primary-600 dark:text-primary-400" : "text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300")} />
              {!collapsed && <span className="font-medium whitespace-nowrap">{item.label}</span>}
              {active && !collapsed && (
                <motion.div 
                  layoutId="active-pill"
                  className="ml-auto w-1.5 h-1.5 rounded-full bg-primary-600 dark:bg-primary-400" 
                />
              )}
            </Link>
          );
        })}
      </nav>
    </motion.aside>
  );
}
