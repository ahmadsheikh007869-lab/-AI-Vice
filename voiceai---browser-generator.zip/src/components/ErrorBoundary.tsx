import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCcw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
          <div className="max-w-md w-full glass p-10 rounded-[40px] text-center space-y-8 border-red-500/20">
            <div className="w-20 h-20 bg-red-500/10 rounded-3xl flex items-center justify-center mx-auto text-red-500">
              <AlertTriangle size={40} />
            </div>
            <div className="space-y-4">
              <h1 className="text-3xl font-display font-bold">Something went wrong</h1>
              <p className="text-slate-400 leading-relaxed">
                We encountered an unexpected error. Our team has been notified.
              </p>
              {this.state.error && (
                <div className="p-4 bg-red-500/5 rounded-2xl text-xs font-mono text-red-400 text-left overflow-auto max-h-32">
                  {this.state.error.message}
                </div>
              )}
            </div>
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => window.location.reload()}
                className="btn-primary w-full py-4 flex items-center justify-center gap-2"
              >
                <RefreshCcw size={20} /> Reload Page
              </button>
              <a 
                href="/"
                className="btn-secondary w-full py-4 flex items-center justify-center gap-2"
              >
                <Home size={20} /> Back to Home
              </a>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
