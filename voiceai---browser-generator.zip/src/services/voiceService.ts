import axios from 'axios';

export interface Voice {
  id: string;
  name: string;
  lang: string;
  localService?: boolean;
  voiceURI?: string;
  provider: 'browser' | 'elevenlabs' | 'openai';
  gender: 'male' | 'female' | 'neutral';
  category: string;
  description?: string;
}

export interface GenerationSettings {
  rate: number;
  pitch: number;
  volume: number;
  stability?: number;
  similarity_boost?: number;
  style?: string;
}

class VoiceService {
  private synth: SpeechSynthesis | null = typeof window !== 'undefined' ? window.speechSynthesis : null;

  private creativeNames: Record<string, { name: string, gender: 'male' | 'female' | 'neutral', category: string }> = {
    'Google हिन्दी': { name: 'Aman (Hindi Male)', gender: 'male', category: 'Hindi' },
    'Microsoft Hemant': { name: 'Hemant (Hindi Male)', gender: 'male', category: 'Hindi' },
    'Microsoft Kalpana': { name: 'Kalpana (Hindi Female)', gender: 'female', category: 'Hindi' },
    'Google UK English Male': { name: 'Arthur (British Male)', gender: 'male', category: 'British' },
    'Google UK English Female': { name: 'Elizabeth (British Female)', gender: 'female', category: 'British' },
    'Google US English': { name: 'John (Calm Male)', gender: 'male', category: 'American' },
    'Microsoft David': { name: 'David (News Anchor Male)', gender: 'male', category: 'American' },
    'Microsoft Zira': { name: 'Zira (Soft Female)', gender: 'female', category: 'American' },
    'Samantha': { name: 'Samantha (Podcast Female)', gender: 'female', category: 'American' },
    'Daniel': { name: 'Daniel (Storyteller Male)', gender: 'male', category: 'British' },
    'Rishi': { name: 'Rishi (Hindi Male)', gender: 'male', category: 'Hindi' },
    'Veena': { name: 'Veena (Hindi Female)', gender: 'female', category: 'Hindi' },
  };

  async fetchVoices(): Promise<Voice[]> {
    const browserVoices = await this.fetchBrowserVoices();
    const premiumVoices = await this.fetchPremiumVoices();
    return [...browserVoices, ...premiumVoices];
  }

  private async fetchBrowserVoices(): Promise<Voice[]> {
    if (!this.synth) return [];

    return new Promise((resolve) => {
      const getMapped = () => {
        const voices = this.synth!.getVoices();
        return voices.map(v => {
          const creative = Object.entries(this.creativeNames).find(([key]) => v.name.includes(key))?.[1];
          return {
            id: v.voiceURI,
            name: creative?.name || v.name,
            lang: v.lang,
            provider: 'browser' as const,
            gender: creative?.gender || (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('zira') || v.name.toLowerCase().includes('samantha') ? 'female' : 'male'),
            category: creative?.category || (v.lang.startsWith('hi') ? 'Hindi' : 'Global')
          };
        });
      };

      let voices = this.synth!.getVoices();
      if (voices.length > 0) {
        resolve(getMapped());
        return;
      }

      this.synth!.onvoiceschanged = () => {
        resolve(getMapped());
      };
    });
  }

  private async fetchPremiumVoices(): Promise<Voice[]> {
    const elevenLabsKey = localStorage.getItem('elevenlabs_api_key');
    if (!elevenLabsKey) return [];

    try {
      const response = await axios.get('/api/voices', {
        headers: { 'xi-api-key': elevenLabsKey }
      });
      return response.data.voices.map((v: any) => ({
        id: v.voice_id,
        name: `${v.name} (Premium)`,
        lang: 'en-US', // ElevenLabs is multilingual but default to en
        provider: 'elevenlabs',
        gender: v.labels?.gender || 'neutral',
        category: 'Premium'
      }));
    } catch (error) {
      return [];
    }
  }

  async generateAudio(text: string, voice: Voice, settings: GenerationSettings): Promise<Blob | null> {
    if (voice.provider === 'browser') {
      this.speak(text, voice.id, settings);
      return null;
    }

    const apiKey = voice.provider === 'elevenlabs' 
      ? localStorage.getItem('elevenlabs_api_key') 
      : localStorage.getItem('openai_api_key');

    if (!apiKey) throw new Error('API Key missing for premium voice');

    const response = await axios.post('/api/generate-voice', {
      text,
      voiceId: voice.id,
      provider: voice.provider,
      settings: {
        stability: settings.stability || 0.5,
        similarity_boost: settings.similarity_boost || 0.75,
        speed: settings.rate
      }
    }, {
      headers: { 'Authorization': apiKey },
      responseType: 'blob'
    });

    return response.data;
  }

  speak(text: string, voiceId: string, settings: GenerationSettings, onEnd?: () => void) {
    if (!this.synth) return;
    this.synth.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    const voices = this.synth.getVoices();
    const selectedVoice = voices.find(v => v.voiceURI === voiceId);

    if (selectedVoice) utterance.voice = selectedVoice;
    utterance.rate = settings.rate;
    utterance.pitch = settings.pitch;
    utterance.volume = settings.volume;
    utterance.onend = () => onEnd?.();

    this.synth.speak(utterance);
  }

  stop() {
    this.synth?.cancel();
  }

  pause() {
    if (this.synth) {
      this.synth.pause();
    }
  }

  resume() {
    if (this.synth) {
      this.synth.resume();
    }
  }

  async testConnection(provider: 'elevenlabs' | 'openai'): Promise<boolean> {
    const key = provider === 'elevenlabs' ? localStorage.getItem('elevenlabs_api_key') : localStorage.getItem('openai_api_key');
    if (!key) return false;

    try {
      if (provider === 'elevenlabs') {
        await axios.get('/api/voices', { headers: { 'xi-api-key': key } });
      } else {
        await axios.post('/api/generate-voice', {
          text: 'test',
          voiceId: 'alloy',
          provider: 'openai',
          settings: { speed: 1.0 }
        }, {
          headers: { 'Authorization': key },
          responseType: 'blob'
        });
      }
      return true;
    } catch (error) {
      return false;
    }
  }
}

export const voiceService = new VoiceService();
